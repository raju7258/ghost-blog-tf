import json
import jwt
import  requests
import os
from datetime import datetime as dt
from io import BytesIO

class GhostAdmin():
    def __init__(self, siteName):
        self.siteName = siteName
        self.site = None
        self.setSiteData()
        self.token = None
        self.headers = None
        self.createHeaders()
        # return self.token
    
    def createToken(self):
        key = self.site['AdminAPIKey']
        id, secret = key.split(':')
        iat = int(dt.now().timestamp())
        header = {'alg': 'HS256', 'typ': 'JWT', 'kid': id}
        payload = {'iat': iat, 'exp': iat + (5 * 60), 'aud': '/v3/admin/'}
        self.token = jwt.encode(payload, bytes.fromhex(secret), algorithm='HS256', headers=header)
    
    def setSiteData(self):
        sites = [{'name': os.environ['NAME'] , 'url': os.environ['URL'] ,'AdminAPIKey':os.environ['AdminAPIKey'], 'ContentAPIKey':os.environ['ContentAPIKey']}]
        self.site = next((site for site in sites if site['name'] == self.siteName), None)
        return None

    def createHeaders(self):
        if self.site != None:
            self.createToken()
            #self.headers = {'Authorization': 'Ghost {}'.format(self.token.decode())}
            self.headers = {'Authorization': 'Ghost {}'.format(self.token)}
        return self.headers
        
    def getAllPosts(self):
        url = self.site['url'] + 'ghost/api/v3/admin/posts/'
        params = {'formats': 'html,mobiledoc', 'limit': 'all', 'filter': 'slug: -tags'}
        result = requests.get(url,  params=params, headers=self.headers)
        posts = json.loads(result.text)['posts']
        return posts
    
    def getSettings(self):
        settings = {}
        url = self.site['url']+'ghost/api/v3/content/settings/?key='+self.site['ContentAPIKey']
        result = requests.get(url, headers=self.headers)
        if result.ok:
            settings = json.loads(result.content)['settings']
        return settings
    def deletePostById(self, id):
        url = self.site['url'] + 'ghost/api/v3/admin/posts/' + id + '/'
        result = requests.delete(url, headers=self.headers)
        if result.ok: result = 'success: post deleted (status_code:' + str(result.status_code) + ')'
        else: result = 'error: post NOT deleted (status_code:' + str(result.status_code) + ')'
        return result

def lambda_handler(event, context):
    # if __name__ == '__main__':
    ga = GhostAdmin(os.environ['HOSTNAME'])   
    settings = ga.getSettings()
    post_a = ga.getAllPosts()
    for item in post_a:
        print('This is Post ID:' + item['id'])
        result = ga.deletePostById(item['id'])
        print ('Result :' + result)
    print("Testing now working")
    #return response